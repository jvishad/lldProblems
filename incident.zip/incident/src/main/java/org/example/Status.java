package org.example;

public enum Status {
    OFFLINE,
    ONLINE;
}
