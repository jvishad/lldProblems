package org.example;


//api ->
//
//post api.
//        /incident?level={}&message={}
//
//
//db ->
//
//
//Incident ->
//
//int level,
//int message
//
//ENUM  ->
//
//
//CRITICAL
//        ERROR
//WARNING
//
//
//service layer -> notification part.
//save it on the db -> in memory
//there would be some check on level -> strategy
//
//directory book -> on call person
//
//
//Alert -> entity
//
//controller ->
//
//IncidentController -> /api/incident?level={}&message={}
//        -->
//service Layer -> saving in the db
//Notification service ->



//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    static void main() {
        // alert
        Alert alert = new Alert("search-service", Severity.CRITICAL, "there is an issue of race condition in file ....");
        IncidentService incidentService = new IncidentService();
        incidentService.processAlert(alert);
    }
}
