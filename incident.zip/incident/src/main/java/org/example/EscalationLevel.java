package org.example;

public enum EscalationLevel {
    PRIMARY(1),
    SECONDARY(2),
    MANAGER(3);

    int priority;

    EscalationLevel(int priority) {
        this.priority = priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }
}
