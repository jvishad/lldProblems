package org.example;

public class Alert {
    String id;
    Severity level;
    String message;

    public Alert(String id, Severity level, String message) {
        this.id = id;
        this.level = level;
        this.message = message;
    }

    public String getId() {
        return id;
    }

    public Severity getLevel() {
        return level;
    }

    public String getMessage() {
        return message;
    }
}
