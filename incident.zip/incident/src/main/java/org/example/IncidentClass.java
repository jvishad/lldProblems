package org.example;


public class IncidentClass {
    String id;
    String message;
    Severity level;

    public IncidentClass(String id, String message, Severity level) {
        this.id = id;
        this.message = message;
        this.level = level;
    }

    public String getMessage() {
        return message;
    }

    public Severity getLevel() {
        return level;
    }
}
