package org.example;

public class onCallPerson {
    String phoneNo;
    String name;
    EscalationLevel level;
    Status status;

    public onCallPerson(String phoneNo, String name, EscalationLevel level, Status status) {
        this.phoneNo = phoneNo;
        this.name = name;
        this.level = level;
        this.status = status;

    }


    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLevel(EscalationLevel level) {
        this.level = level;
    }

}
