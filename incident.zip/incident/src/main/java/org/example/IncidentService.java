package org.example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IncidentService {
    List<IncidentClass> incidentStore = new ArrayList<>();
    Map<String, List<onCallPerson>> onCallDirectory = new HashMap<>();

    public IncidentService() {
        onCallPerson primary = new onCallPerson("123", "a", EscalationLevel.PRIMARY, Status.OFFLINE);
        onCallPerson secondary = new onCallPerson("1234", "a", EscalationLevel.PRIMARY, Status.OFFLINE);
        onCallPerson manager = new onCallPerson("12345", "a", EscalationLevel.PRIMARY, Status.ONLINE);

        List<onCallPerson> SearchOnCallList = new ArrayList<>();
        SearchOnCallList.add(primary);
        SearchOnCallList.add(secondary);
        SearchOnCallList.add(manager);
        onCallDirectory.put("search-service", SearchOnCallList);
    }


    // process an alert
    public IncidentClass processAlert(Alert alert) {
        IncidentClass incident = new IncidentClass(alert.getId(), alert.getMessage(),
                alert.getLevel());
        List<onCallPerson> personList = onCallDirectory.get(alert.getId());

        String phoneNumber = "";

        for (onCallPerson onCallPerson : personList) {
            if (onCallPerson.status == Status.ONLINE) {
                phoneNumber = onCallPerson.phoneNo;
            }
        }
        incidentStore.add(incident);
        //level = critical -----> notify the on call person

        if (alert.getLevel() == Severity.CRITICAL) {
            // external api call
            System.out.println("please make a phone call on " + phoneNumber + " is an issue in the search service " + alert.getMessage());
        } // level = error ------> sent a message
        else if (alert.getLevel() == Severity.ERROR) {
            System.out.println("message delivered to the phone no " + phoneNumber + " is an issue in the search service " + alert.getMessage());
        }  // level = warning, only persist in the database
        else {
            System.out.println("Message persisted to the db");
        }

        return incident;
    }


}
