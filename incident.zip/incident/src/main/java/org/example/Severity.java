package org.example;

public enum Severity {
    CRITICAL,
    ERROR,
    WARNING
}
