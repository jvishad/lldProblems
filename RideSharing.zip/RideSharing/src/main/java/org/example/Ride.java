package org.example;

//Ride -> userName, origin, destination, avlSeats, vehicle, startTime, duration

import java.time.LocalDateTime;
import java.util.Date;

public class Ride {
    String rideId;
    String userName;
    String origin;
    String destination;
    int avlSeats;
    String vehicleName;
    LocalDateTime startTime;
    int duration;


    public String getRideId() {
        return rideId;
    }

    public int getAvlSeats() {
        return avlSeats;
    }

    public String getUserName() {
        return userName;
    }

    public String getOrigin() {
        return origin;
    }

    public String getDestination() {
        return destination;
    }

    public String getVehicleName() {
        return vehicleName;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }


    public int getDuration() {
        return duration;
    }

    public Ride(String rideId, String userName, String origin, String destination,
                int avlSeats, String vehicleName, LocalDateTime startTime, int duration) {
        this.rideId = rideId;
        this.userName = userName;
        this.origin = origin;
        this.destination = destination;
        this.avlSeats = avlSeats;
        this.vehicleName = vehicleName;
        this.startTime = startTime;
        this.duration = duration;
    }


}
