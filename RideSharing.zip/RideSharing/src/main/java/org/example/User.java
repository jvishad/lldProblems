package org.example;

public class User {
    String name;
    Gender gender;
    int age;

    public User(String name, Gender gender, int age) {
        this.name = name;
        this.gender = gender;
        this.age = age;
    }
}
