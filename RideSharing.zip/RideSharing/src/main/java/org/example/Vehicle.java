package org.example;

//User -> id, name, gender, age
//Vehicle -> vehicleId, vehicleName, ownerName
//Ride -> userName, origin, destination, avlSeats, vehicle, startTime, duration

public class Vehicle {
    String vehicleNo;
    String ownerName;
    String vehicleName;

    public Vehicle(String vehicleNo, String ownerName, String vehicleName) {
        this.vehicleNo = vehicleNo;
        this.ownerName = ownerName;
        this.vehicleName = vehicleName;
    }

}
