package org.example;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RideWebApplication {
    SelectionStrategy selectionStrategy;
    Map<String, User> userMap = new HashMap<>();
    Map<String, Vehicle> vehicleMap = new HashMap<>();
    List<Ride> rideList = new ArrayList<>();
    Map<String, Integer> fuelSaved = new HashMap<>();

    // the one who is offering ride, count
    Map<String, Integer> rideOffered = new HashMap<>();

    // the one who is taking ride, count
    Map<String, Integer> rideTaken = new HashMap<>();


    void addUser(String name, Gender gender, int age) {
        User user = new User(name, gender, age);
        userMap.put(name, user);
        rideOffered.put(name, 0);
        rideTaken.put(name, 0);
        fuelSaved.put(name, 0);
    }

    void addVehicle(String vehicleNo, String vehicleName, String ownerName) {
        Vehicle vehicle = new Vehicle(vehicleNo, vehicleName, ownerName);
        vehicleMap.put(vehicleNo, vehicle);
    }

//    offer_ride(“Rohan, Origin=Hyderabad, Available Seats=1, Vehicle=Swift, KA-01-12345, Destination= Bangalore, Start Time=25th Jan, 2019 08:00, ride_duration=13 hrs”)


    void offerRide(String rideId, String userName, String origin, String des, int avlSeats, String vehicleName,
                   LocalDateTime startTime, int rideDuration) {
        Ride ride = new Ride(rideId, userName, origin, des, avlSeats, vehicleName, startTime, rideDuration);
        rideList.add(ride);
        rideOffered.put(userName, rideOffered.getOrDefault(userName, 0) + 1);
    }


//    “Nandini, Origin=Bangalore, Destination=Mysore, Fastest Ride”)

    void selectRide(String name, String origin, String des, SelectionStrategy strategy) {
        // selection strategy pattern

        Ride ride = strategy.selectRide(origin, des, rideList);
        if(ride == null) {
            System.out.println("Can't find ride for origin " + origin + " destination " + des);
            return;
        }
        rideTaken.put(name, rideTaken.getOrDefault(name, 0) + 1);
        fuelSaved.put(name, fuelSaved.getOrDefault(name, 0) + ride.duration);

        System.out.println("Found Ride with details " + ride.getRideId());
    }

    void printFuelSavedStats() {
        System.out.println(fuelSaved);


        System.out.println("---------------------");

        System.out.println(rideOffered);
        System.out.println(rideTaken);

    }
}
