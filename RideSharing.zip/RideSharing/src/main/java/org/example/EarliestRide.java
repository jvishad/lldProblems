package org.example;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalUnit;
import java.util.List;

public class EarliestRide implements SelectionStrategy {
    @Override
    public Ride selectRide(String origin, String destination, List<Ride> availableRides) {
        // in all the ride choose the best earliest

//        r1 r2 r3 r4 r5 -> compare all the rides

        Ride selectedRide = null;
        LocalDateTime earliestEndTime = LocalDateTime.MAX;

        for (Ride ride : availableRides) {
            // need to check if it has origin and destination
            if (ride.getOrigin().equals(origin) && ride.getDestination().equals(destination)) {
                LocalDateTime endTime = ride.getStartTime().plus(ride.duration, ChronoUnit.HOURS);
                if (endTime.isBefore(earliestEndTime)) {
                    earliestEndTime = endTime;
                    selectedRide = ride;
                }
            }
        }

        return selectedRide;
    }
}

