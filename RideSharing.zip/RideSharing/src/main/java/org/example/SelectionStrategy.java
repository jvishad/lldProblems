package org.example;

import java.util.List;

public interface SelectionStrategy {
    Ride selectRide(String origin, String destination, List<Ride> allRides);
}
