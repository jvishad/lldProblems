package org.example;

import java.time.LocalDateTime;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    static void main() {
//         add_vehicle(“Rohan, Swift, KA-01-12345)
//         add_vehicle(“Shashank, Baleno, TS-05-62395)
//        add_vehicle(“Shipra”, Polo, KA-05-41491); add_vehicle(“Shipra, Scooty KA-12-12332”)

//        offer_ride(“Rohan, Origin=Hyderabad, Available Seats=1, Vehicle=Swift, KA-01-12345, Destination= Bangalore, Start Time=25th Jan, 2019 08:00, ride_duration=13 hrs”)
//        offer_ride(“Shipra, Origin=Bangalore, Available Seats=1, Vehicle=Scooty KA-12-12332, Destination=Mysore,Start Time= 29th Jan, 2019 18:00, ride_duration=10 hrs”)
//        offer_ride(“Shipra, Origin=Bangalore, Available Seats=2, Vehicle=Polo, KA-05-41491, Destination=Mysore, Start Time=30th Jan, 2019 18:00, ride_duration=4 hrs”)
//        offer_ride(“Shashank, Origin=Hyderabad, Available Seats=2, Vehicle=Baleno, TS-05-62395, Destination=Bangalore, Start Time=27th Jan, 2019 10:00, ride_duration=14 hrs”)


        RideWebApplication rideApp = new RideWebApplication();
        rideApp.addUser("Rohan", Gender.MALE, 36);
        rideApp.addUser("Shashank", Gender.MALE, 29);
        rideApp.addUser("Nandini", Gender.FEMALE, 29);
        rideApp.addUser("Shipra", Gender.FEMALE, 27);
        rideApp.addUser("Gaurav", Gender.MALE, 29);


        rideApp.addVehicle("KA-01-12345", "Rohan", "Swift");
        rideApp.addVehicle("TS-05-62395", "Shashank", "Swift");
        rideApp.addVehicle("KA-05-41491", "Shipra", "Swift");

//        25th Jan, 2019 08:00
//        29 th Jan, 2019 18:00, 10
//        30 th Jan, 2019 18:00, 4
//        27 th Jan, 2019 10:00, 14
        rideApp.offerRide("1", "Rohan", "Hyderabad", "Bangalore", 1, "Swift", LocalDateTime.of(2019, 1, 25, 8, 0), 13);
        rideApp.offerRide("2", "Shipra", "Bangalore", "Mysore", 1, "Scooty", LocalDateTime.of(2019, 1, 29, 18, 0), 10);
        rideApp.offerRide("3", "Shipra", "Bangalore", "Mysore", 2, "Polo", LocalDateTime.of(2019, 1, 30, 18, 0), 4);
        rideApp.offerRide("4", "Shashank", "Hyderabad", "Bangalore", 2, "Baleno", LocalDateTime.of(2019, 1, 27, 10, 0), 14);

        rideApp.selectRide("Nandini", "Bangalore", "Mysore", new FastestRide());
        rideApp.selectRide("Gaurav", "Bangalore", "Mysore", new EarliestRide());
        rideApp.selectRide("Shashank", "Mumbai", "Bangalore", new FastestRide());
        rideApp.selectRide("Nandini", "Hyderabad", "Bangalore", new FastestRide());


        System.out.println("-----------------------");

        rideApp.printFuelSavedStats();

    }
}
