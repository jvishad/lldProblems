package org.example;

import java.util.List;

public class FastestRide implements SelectionStrategy {
    @Override
    public Ride selectRide(String origin, String destination, List<Ride> availableRides) {
        // in all the ride choose the best fastest

//        r1 r2 r3 r4 r5 -> compare all the rides

        Ride selectedRide = null;
        int maxDuration = Integer.MAX_VALUE;

        for (Ride ride : availableRides) {
            // need to check if it has origin and destination
            if (ride.getOrigin().equals(origin) && ride.getDestination().equals(destination)) {
                if (ride.getDuration() < maxDuration) {
                    maxDuration = ride.getDuration();
                    selectedRide = ride;
                }
            }
        }

        return selectedRide;
    }
}
